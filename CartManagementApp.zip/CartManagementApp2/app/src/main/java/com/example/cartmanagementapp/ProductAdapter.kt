package com.example.cartmanagementapp

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ProductAdapter(
    private val productList: List<Product>,
    private val cart: MutableList<Product>
) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    // ViewHolder class to hold individual product views
    inner class ProductViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val productNameTextView: TextView = itemView.findViewById(R.id.productNameTextView)
        private val productPriceTextView: TextView = itemView.findViewById(R.id.productPriceTextView)
        private val addToCartButton: Button = itemView.findViewById(R.id.addToCartButton)

        @SuppressLint("DefaultLocale")
        fun bind(product: Product) {
            // Bind product details
            productNameTextView.text = product.name
            productPriceTextView.text = String.format("$%.2f", product.price)

            // Handle button click for adding to cart
            addToCartButton.setOnClickListener {
                if (!cart.contains(product)) {
                    product.quantity = 1
                    cart.add(product)
                } else {
                    product.quantity++
                }
                notifyItemChanged(adapterPosition) // Update the specific item's view
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_product, parent, false)
        return ProductViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        holder.bind(productList[position])
    }

    override fun getItemCount(): Int = productList.size
}
