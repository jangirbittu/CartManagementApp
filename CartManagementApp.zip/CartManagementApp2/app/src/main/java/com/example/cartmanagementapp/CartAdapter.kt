package com.example.cartmanagementapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.cartmanagementapp.databinding.ItemCartBinding

class CartAdapter(
    private val cart: MutableList<Product>,
    private val onCartUpdated: () -> Unit // Callback to notify when cart updates
) : RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    inner class CartViewHolder(private val binding: ItemCartBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(product: Product) {
            binding.cartItemNameTextView.text = product.name
            binding.cartItemQuantityTextView.text = "Qty: ${product.quantity}"
            binding.cartItemPriceTextView.text = "Price: $${product.price * product.quantity}"

            // Handle quantity increase
            binding.increaseQuantityButton.setOnClickListener {
                product.quantity++
                onCartUpdated() // Notify cart is updated
                notifyDataSetChanged()
            }

            // Handle quantity decrease
            binding.decreaseQuantityButton.setOnClickListener {
                if (product.quantity > 1) {
                    product.quantity--
                } else {
                    cart.remove(product) // Remove product if quantity goes to 0
                }
                onCartUpdated() // Notify cart is updated
                notifyDataSetChanged()
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val binding = ItemCartBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CartViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        holder.bind(cart[position])
    }

    override fun getItemCount(): Int = cart.size
}
