package com.example.cartmanagementapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.cartmanagementapp.databinding.ActivityCartBinding

class CartActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCartBinding
    private val cart = mutableListOf<Product>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCartBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Retrieve cart data from Intent
        val cartItems = intent.getParcelableArrayListExtra<Product>("cart")
        if (cartItems != null) {
            cart.addAll(cartItems)
        }

        // Set up RecyclerView
        val adapter = CartAdapter(cart) {
            updateTotalPrice() // Provide the implementation for onCartUpdated
        }
        binding.cartRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.cartRecyclerView.adapter = adapter

        // Initialize total price
        updateTotalPrice()
    }

    private fun updateTotalPrice() {
        val total = cart.sumOf { it.price * it.quantity }
        binding.totalPriceTextView.text = "Total: $${"%.2f".format(total)}"
    }
}
