package com.example.cartmanagementapp

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.cartmanagementapp.databinding.ActivityMainBinding
import com.example.cartmanagementapp.databinding.DialogAddProductBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val productList = mutableListOf<Product>()
    private val cart = mutableListOf<Product>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Sample products
        productList.addAll(
            listOf(
                Product(1, "Apple", 1.0),
                Product(2, "Banana", 0.5),
                Product(3, "Orange", 0.75)
            )
        )

        // Set up RecyclerView
        binding.productRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.productRecyclerView.adapter = ProductAdapter(productList, cart)

        // View Cart Button Listener
        binding.viewCartButton.setOnClickListener {
            val intent = Intent(this, CartActivity::class.java)
            intent.putParcelableArrayListExtra("cart", ArrayList(cart))
            startActivity(intent)
        }

        // Add Product Button Listener
        binding.addProductButton.setOnClickListener {
            showAddProductDialog()
        }
    }

    private fun showAddProductDialog() {
        val dialogBinding = DialogAddProductBinding.inflate(LayoutInflater.from(this))
        val dialogBuilder = AlertDialog.Builder(this)
        dialogBuilder.setView(dialogBinding.root)
        val dialog = dialogBuilder.create()

        dialogBinding.addButton.setOnClickListener {
            val name = dialogBinding.productNameEditText.text.toString().trim()
            val price = dialogBinding.productPriceEditText.text.toString().toDoubleOrNull()

            if (name.isNotEmpty() && price != null) {
                val newProduct = Product(productList.size + 1, name, price)
                productList.add(newProduct)
                binding.productRecyclerView.adapter?.notifyDataSetChanged()
                dialog.dismiss()
            } else {
                dialogBinding.productNameEditText.error = "Enter a valid name"
                dialogBinding.productPriceEditText.error = "Enter a valid price"
            }
        }

        dialogBinding.cancelButton.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }
}
